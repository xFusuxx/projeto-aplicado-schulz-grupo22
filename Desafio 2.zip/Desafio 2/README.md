# Projeto Aplicado I — Schulz S.A.
## Entrega 02 — Modelagem e Estruturação de Banco de Dados Relacional (SQLite)

**Grupo:** 22  
**Integrantes:** 
- Davi da Silva Simao
- Guilherme Ceschiatti Barbosa Moreira
- José Altair Araujo Camargo
- Maurício Fusuma Oliveira
- Rafael Nunes da Fonseca

**Orientadores:** Prof. MSc. Hugo Menezes Barra e Prof. Rodrigo Losina  
**Instituição:** UniSENAI — Centro Universitário Senai / Projeto Aplicado I  

---

## Contexto do Projeto
No **Desafio 1**, identificou-se que a transcrição manual de medições obtidas na Máquina de Medição por Coordenadas (MMC) para os certificados de calibração gera gargalos operacionais, retrabalho e riscos de erros de digitação. 

Para resolver esse problema, esta **Entrega 02** estrutura a base de dados relacional em **SQLite**, garantindo a integridade referencial e normalização dos dados para viabilizar a futura importação automática e emissão de certificados em PDF.

---

## Estrutura do Repositório

* **`main.py`**: Script unificado em Python que gera a documentação em Markdown, o script DDL SQL e compila a base de dados SQLite.
* **`01_estrutura.md`**: Descrição do problema, justificativa da modelagem, entidades (`tecnico`, `equipamento`, `medicao`) e normalização.
* **`02_dicionario.md`**: Dicionário de dados detalhando os 19 atributos do sistema, tipos SQLite e regras de negócio/tolerâncias.
* **`03_banco.sql`**: Script DDL executável contendo as chaves primárias (PK), chaves estrangeiras (FK) e restrições `CHECK`.
* **`schulz_calibracao.db`**: Arquivo do banco de dados relacional gerado após a execução.

---

## Como Executar o Projeto

1. Certifique-se de ter o **Python 3.x** instalado.
2. Clone o repositório ou baixe os arquivos em sua máquina local.
3. Abra o terminal na raiz do projeto e execute:

```bash
python main.py