import sqlite3
from pathlib import Path

estrutura = """# Projeto Aplicado I — Schulz S.A.
## Entrega 02 — Modelagem e Estruturação de Banco de Dados

**Grupo:** 22  
**Integrantes:** José Altair Araujo Camargo; Guilherme Ceschiatti Barbosa Moreira; Davi da Silva Simao; Maurício Fusuma Oliveira; Rafael Nunes da Fonseca 
**Orientadores:** Prof. MSc. Hugo Menezes Barra e Prof. Rodrigo Losina

## 1. Contexto e problema
No Desafio 1, identificamos que o técnico executante realiza as medições na Máquina de Medição por Coordenadas (MMC), enquanto outro técnico transfere manualmente os resultados para o certificado.
Essa transferência manual aumenta o tempo de emissão e pode provocar erros de digitação, associação incorreta de parâmetros e retrabalho.
O responsável pela área continua encarregado da conferência e assinatura do certificado.
O objetivo desta etapa é organizar o armazenamento dos dados para apoiar a futura importação, validação e emissão automatizada de certificados em PDF.
O banco relacional escolhido no roteiro é o SQLite.

## 2. Entidades principais
### 2.1 Técnico
A tabela `tecnico` identifica o profissional responsável pela execução da medição.
Contém identificador, nome, matrícula, e-mail e setor. O cadastro é único e pode ser relacionado a diversas medições.

### 2.2 Equipamento
A tabela `equipamento` registra o instrumento ou dispositivo calibrado.
Armazena identificador, código/tag, denominação, fabricante e modelo. A tag é única para evitar duplicação.

### 2.3 Medição
A tabela `medicao` guarda cada resultado por parâmetro medido.
Relaciona um equipamento e um técnico por chaves estrangeiras.

## 3. Relacionamentos e integridade
Um técnico pode realizar muitas medições (1:N). Um equipamento pode ter muitas medições (1:N).
As chaves estrangeiras garantem a integridade referencial. O status fica limitado a APROVADO ou REPROVADO.

## 4. Justificativa da normalização
Separar técnico e equipamento evita repetir dados cadastrais a cada nova medição, diminuindo inconsistências e facilitando consultas.

## 5. Limites desta entrega
Este modelo é um primeiro recorte acadêmico do sistema completo. Funcionalidades como importação automática de arquivos MMC e geração de PDF serão tratadas nas próximas etapas.
"""

dicionario = """# Projeto Aplicado I — Schulz S.A.
## Entrega 02 — Dicionário de Dados — SQLite

### Tabela `tecnico`
| Campo | Tipo | Chave / restrição | Descrição |
|---|---|---|---|
| `id_tecnico` | INTEGER | PK AUTOINCREMENT | Identificador único |
| `nome_tecnico` | TEXT | NOT NULL | Nome do executor |
| `matricula` | TEXT | NOT NULL UNIQUE | Matrícula do colaborador |
| `email` | TEXT | NOT NULL | Contato institucional |
| `setor` | TEXT | NOT NULL | Área de atuação |

### Tabela `equipamento`
| Campo | Tipo | Chave / restrição | Descrição |
|---|---|---|---|
| `id_equipamento` | INTEGER | PK AUTOINCREMENT | Identificador único |
| `codigo_tag` | TEXT | NOT NULL UNIQUE | Código do dispositivo |
| `nome_equipamento` | TEXT | NOT NULL | Denominação do instrumento |
| `fabricante` | TEXT | NOT NULL | Fabricante |
| `modelo` | TEXT | NOT NULL | Modelo do instrumento |

### Tabela `medicao`
| Campo | Tipo | Chave / restrição | Descrição |
|---|---|---|---|
| `id_medicao` | INTEGER | PK AUTOINCREMENT | Identificador único |
| `id_equipamento` | INTEGER | NOT NULL FK | Referência ao equipamento |
| `id_tecnico` | INTEGER | NOT NULL FK | Referência ao técnico executor |
| `parametro_medido` | TEXT | NOT NULL | Característica avaliada |
| `valor_nominal` | REAL | NOT NULL | Valor de referência |
| `tolerancia_min` | REAL | NOT NULL | Limite inferior do erro |
| `tolerancia_max` | REAL | NOT NULL | Limite superior do erro |
| `valor_obtido` | REAL | NOT NULL | Resultado obtido na medição |
| `status_resultado` | TEXT | NOT NULL CHECK | APROVADO ou REPROVADO |
| `data_medicao` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Data e hora do registro |

## Regras de negócio
- Código/tag do equipamento e matrícula do técnico são únicos.
- Medição deve referenciar um técnico e equipamento existentes.
- Status limitado a APROVADO ou REPROVADO.
- Tolerância aplicada sobre o erro (valor obtido - valor nominal).
"""

sql = """PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS tecnico (
  id_tecnico INTEGER PRIMARY KEY AUTOINCREMENT,
  nome_tecnico TEXT NOT NULL,
  matricula TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  setor TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS equipamento (
  id_equipamento INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo_tag TEXT NOT NULL UNIQUE,
  nome_equipamento TEXT NOT NULL,
  fabricante TEXT NOT NULL,
  modelo TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS medicao (
  id_medicao INTEGER PRIMARY KEY AUTOINCREMENT,
  id_equipamento INTEGER NOT NULL,
  id_tecnico INTEGER NOT NULL,
  parametro_medido TEXT NOT NULL,
  valor_nominal REAL NOT NULL,
  tolerancia_min REAL NOT NULL,
  tolerancia_max REAL NOT NULL,
  valor_obtido REAL NOT NULL,
  status_resultado TEXT NOT NULL CHECK (status_resultado IN ('APROVADO','REPROVADO')),
  data_medicao DATETIME DEFAULT CURRENT_TIMESTAMP,
  CHECK (tolerancia_min <= tolerancia_max),
  FOREIGN KEY (id_equipamento) REFERENCES equipamento(id_equipamento) ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (id_tecnico) REFERENCES tecnico(id_tecnico) ON DELETE RESTRICT ON UPDATE CASCADE
);"""

Path("01_estrutura.md").write_text(estrutura, encoding="utf-8")
Path("02_dicionario.md").write_text(dicionario, encoding="utf-8")
Path("03_banco.sql").write_text(sql, encoding="utf-8")

with sqlite3.connect("schulz_calibracao.db") as conn:
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(sql)